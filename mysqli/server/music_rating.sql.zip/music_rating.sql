-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 31 maj 2012 kl 12:17
-- Serverversion: 5.1.53
-- PHP-version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `music_rating`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `album`
--

CREATE TABLE IF NOT EXISTS `album` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `release_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Data i tabell `album`
--

INSERT INTO `album` (`id`, `name`, `release_date`) VALUES
(1, 'Let Love In', '0000-00-00'),
(2, 'Retro - John McCready FAN', '0000-00-00'),
(3, 'Substance (Disc 2)', '1980-03-23'),
(4, 'Retro - Miranda Sawyer POP', '1945-02-23'),
(5, 'Retro - New Order / Bobby Gillespie LIVE', '1976-02-23'),
(6, 'Live Around The World', '1987-02-23'),
(8, 'Power, Corruption & Lies', '1995-02-23'),
(10, 'Substance 1987 (Disc 1)', '2005-02-23'),
(11, 'Second Coming', '1995-02-23'),
(12, 'Light Years', '1985-02-23'),
(13, 'Brotherhood', '1975-02-23');

-- --------------------------------------------------------

--
-- Struktur för tabell `album_artist`
--

CREATE TABLE IF NOT EXISTS `album_artist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(10) NOT NULL,
  `artist_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `album_id` (`album_id`,`artist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data i tabell `album_artist`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `artist`
--

CREATE TABLE IF NOT EXISTS `artist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Data i tabell `artist`
--

INSERT INTO `artist` (`id`, `name`) VALUES
(1, 'New Order'),
(2, 'Nick Cave & The Bad Seeds'),
(3, 'Miles Davis'),
(4, 'The Rolling Stones'),
(5, 'The Stone Roses'),
(6, 'Kylie Minogue');

-- --------------------------------------------------------

--
-- Struktur för tabell `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Data i tabell `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'love'),
(2, 'speed'),
(3, 'joy'),
(4, 'radge'),
(5, 'fear');

-- --------------------------------------------------------

--
-- Struktur för tabell `genre`
--

CREATE TABLE IF NOT EXISTS `genre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Data i tabell `genre`
--

INSERT INTO `genre` (`id`, `name`) VALUES
(1, 'Rock'),
(2, 'Pop'),
(3, 'Metal'),
(4, 'Jazz'),
(5, 'Hop-hop');

-- --------------------------------------------------------

--
-- Struktur för tabell `genre_song`
--

CREATE TABLE IF NOT EXISTS `genre_song` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `genre_id` int(10) NOT NULL,
  `song_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `genre_id` (`genre_id`,`song_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Data i tabell `genre_song`
--

INSERT INTO `genre_song` (`id`, `genre_id`, `song_id`) VALUES
(1, 1, 1),
(2, 3, 1),
(3, 2, 2),
(4, 4, 2),
(5, 1, 3),
(6, 4, 4),
(7, 5, 5),
(8, 5, 6),
(9, 4, 6),
(10, 5, 7),
(11, 2, 8),
(12, 4, 9),
(13, 5, 9),
(14, 2, 10),
(15, 1, 11),
(16, 5, 11),
(17, 2, 12),
(18, 3, 13),
(19, 4, 13),
(20, 1, 14),
(21, 1, 15),
(22, 3, 15),
(23, 4, 15),
(24, 2, 16),
(25, 2, 17),
(26, 3, 18),
(27, 3, 19),
(28, 5, 19),
(29, 1, 20),
(30, 2, 21),
(31, 1, 22),
(32, 2, 22),
(33, 4, 23),
(34, 4, 24),
(35, 5, 24);

-- --------------------------------------------------------

--
-- Struktur för tabell `playlists`
--

CREATE TABLE IF NOT EXISTS `playlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `user_id` int(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Data i tabell `playlists`
--

INSERT INTO `playlists` (`id`, `name`, `user_id`, `date`) VALUES
(30, 'Kulmusik', 17, '2012-05-29'),
(23, 'Kaaalas', 17, '2012-05-29'),
(22, 'Kalasmusik', 17, '2012-05-29'),
(27, 'Julmusik', 17, '2012-05-29'),
(20, 'Thors favossar', 17, '2012-05-29'),
(19, 'Palles bÃ¤sta', 17, '2012-05-29'),
(29, 'Finemang', 17, '2012-05-29'),
(18, 'hej', 17, '2012-05-29'),
(28, 'Julmusik', 17, '2012-05-29'),
(26, 'Hello', 17, '2012-05-29'),
(31, 'Lalala', 17, '2012-05-29'),
(32, 'Ã…rstider', 17, '2012-05-29'),
(33, 'Summertime', 17, '2012-05-29'),
(34, 'sommar', 2, '2012-05-29'),
(35, 'Rackarns', 3, '2012-05-29'),
(36, 'Knarkfest', 3, '2012-05-29'),
(37, 'Halleluja', 3, '2012-05-29'),
(38, 'Herregud', 1, '2012-05-29'),
(39, 'Kurredutt', 2, '2012-05-29'),
(40, 'Julmusik', 1, '2012-05-30'),
(41, 'Kalasmusik', 3, '2012-05-31');

-- --------------------------------------------------------

--
-- Struktur för tabell `playlist_rights`
--

CREATE TABLE IF NOT EXISTS `playlist_rights` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int(10) unsigned NOT NULL,
  `playlist_id` int(10) unsigned NOT NULL,
  `right_to_change` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id` (`users_id`,`playlist_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Data i tabell `playlist_rights`
--

INSERT INTO `playlist_rights` (`id`, `users_id`, `playlist_id`, `right_to_change`) VALUES
(1, 3, 37, 0),
(2, 2, 34, 1),
(3, 3, 33, 0),
(4, 1, 40, 1),
(7, 4, 40, 1),
(8, 3, 40, 1),
(9, 2, 41, 1);

-- --------------------------------------------------------

--
-- Struktur för tabell `playlist_song`
--

CREATE TABLE IF NOT EXISTS `playlist_song` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `playlist_id` int(10) NOT NULL,
  `song_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `playlist_id` (`playlist_id`,`song_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Data i tabell `playlist_song`
--

INSERT INTO `playlist_song` (`id`, `playlist_id`, `song_id`) VALUES
(1, 30, 5),
(2, 17, 17),
(3, 17, 20),
(4, 17, 8),
(5, 17, 19),
(6, 34, 20),
(23, 38, 12),
(8, 34, 15),
(9, 34, 3),
(10, 39, 20),
(11, 39, 1),
(12, 39, 6),
(13, 39, 3),
(22, 40, 21),
(15, 34, 2),
(16, 34, 21),
(17, 34, 6),
(18, 34, 1),
(19, 39, 17),
(24, 38, 22),
(21, 37, 22),
(25, 38, 16),
(26, 38, 8),
(32, 37, 21),
(28, 40, 16),
(29, 40, 22),
(30, 40, 6),
(31, 40, 2),
(33, 36, 17),
(34, 36, 3),
(35, 36, 6),
(36, 36, 21),
(37, 35, 18),
(38, 35, 6),
(39, 35, 21),
(40, 35, 2),
(41, 35, 17),
(45, 41, 22),
(43, 41, 1),
(44, 41, 11);

-- --------------------------------------------------------

--
-- Struktur för tabell `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `song_id` int(10) DEFAULT NULL,
  `rating` int(2) unsigned NOT NULL,
  `users_id` int(10) unsigned NOT NULL,
  `categories_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=153 ;

--
-- Data i tabell `ratings`
--

INSERT INTO `ratings` (`id`, `song_id`, `rating`, `users_id`, `categories_id`) VALUES
(1, 6, 1, 17, 1),
(2, 6, 4, 17, 2),
(3, 6, 4, 17, 3),
(4, 6, 4, 17, 4),
(5, 6, 1, 17, 1),
(6, 6, 1, 17, 2),
(7, 6, 1, 17, 3),
(8, 6, 1, 17, 4),
(9, 6, 1, 17, 1),
(10, 6, 1, 17, 2),
(11, 6, 1, 17, 3),
(12, 6, 1, 17, 4),
(13, 11, 10, 17, 1),
(14, 11, 2, 17, 2),
(15, 11, 10, 17, 3),
(16, 11, 2, 17, 4),
(17, 20, 2, 2, 1),
(18, 20, 6, 2, 2),
(19, 20, 3, 2, 3),
(20, 20, 1, 2, 4),
(21, 20, 10, 3, 1),
(22, 20, 1, 3, 2),
(23, 20, 10, 3, 3),
(24, 20, 1, 3, 4),
(25, 14, 5, 1, 1),
(26, 14, 5, 1, 2),
(27, 14, 5, 1, 3),
(28, 14, 5, 1, 4),
(29, 8, 5, 1, 1),
(30, 8, 5, 1, 2),
(31, 8, 5, 1, 3),
(32, 8, 5, 1, 4),
(33, 17, 2, 2, 1),
(34, 17, 8, 2, 2),
(35, 17, 8, 2, 3),
(36, 17, 8, 2, 4),
(37, NULL, 4, 2, 1),
(38, NULL, 1, 2, 2),
(39, NULL, 5, 2, 3),
(40, NULL, 5, 2, 4),
(41, NULL, 5, 2, 1),
(42, NULL, 5, 2, 2),
(43, NULL, 2, 2, 3),
(44, NULL, 5, 2, 4),
(45, NULL, 5, 2, 1),
(46, NULL, 5, 2, 2),
(47, NULL, 5, 2, 3),
(48, NULL, 5, 2, 4),
(49, NULL, 5, 2, 1),
(50, NULL, 5, 2, 2),
(51, NULL, 5, 2, 3),
(52, NULL, 5, 2, 4),
(53, NULL, 5, 2, 1),
(54, NULL, 5, 2, 2),
(55, NULL, 5, 2, 3),
(56, NULL, 5, 2, 4),
(57, NULL, 5, 2, 1),
(58, NULL, 5, 2, 2),
(59, NULL, 5, 2, 3),
(60, NULL, 5, 2, 4),
(61, NULL, 5, 2, 1),
(62, NULL, 5, 2, 2),
(63, NULL, 5, 2, 3),
(64, NULL, 5, 2, 4),
(65, NULL, 5, 2, 1),
(66, NULL, 5, 2, 2),
(67, NULL, 7, 2, 3),
(68, NULL, 5, 2, 4),
(69, NULL, 5, 2, 1),
(70, NULL, 5, 2, 2),
(71, NULL, 5, 2, 3),
(72, NULL, 5, 2, 4),
(73, NULL, 5, 2, 1),
(74, NULL, 5, 2, 2),
(75, NULL, 5, 2, 3),
(76, NULL, 5, 2, 4),
(77, NULL, 5, 2, 1),
(78, NULL, 5, 2, 2),
(79, NULL, 5, 2, 3),
(80, NULL, 5, 2, 4),
(81, NULL, 5, 2, 1),
(82, NULL, 5, 2, 2),
(83, NULL, 5, 2, 3),
(84, NULL, 5, 2, 4),
(85, NULL, 5, 2, 1),
(86, NULL, 5, 2, 2),
(87, NULL, 5, 2, 3),
(88, NULL, 5, 2, 4),
(89, NULL, 5, 2, 1),
(90, NULL, 5, 2, 2),
(91, NULL, 5, 2, 3),
(92, NULL, 5, 2, 4),
(93, NULL, 5, 2, 1),
(94, NULL, 5, 2, 2),
(95, NULL, 5, 2, 3),
(96, NULL, 5, 2, 4),
(97, NULL, 5, 2, 1),
(98, NULL, 5, 2, 2),
(99, NULL, 5, 2, 3),
(100, NULL, 5, 2, 4),
(101, NULL, 5, 2, 1),
(102, NULL, 5, 2, 2),
(103, NULL, 5, 2, 3),
(104, NULL, 5, 2, 4),
(105, NULL, 5, 2, 1),
(106, NULL, 5, 2, 2),
(107, NULL, 5, 2, 3),
(108, NULL, 5, 2, 4),
(109, NULL, 5, 2, 1),
(110, NULL, 5, 2, 2),
(111, NULL, 5, 2, 3),
(112, NULL, 5, 2, 4),
(113, NULL, 5, 2, 1),
(114, NULL, 5, 2, 2),
(115, NULL, 5, 2, 3),
(116, NULL, 5, 2, 4),
(117, NULL, 5, 2, 1),
(118, NULL, 5, 2, 2),
(119, NULL, 5, 2, 3),
(120, NULL, 5, 2, 4),
(121, 19, 5, 2, 1),
(122, 19, 5, 2, 2),
(123, 19, 5, 2, 3),
(124, 19, 5, 2, 4),
(125, 3, 5, 18, 1),
(126, 3, 5, 18, 2),
(127, 3, 5, 18, 3),
(128, 3, 2, 18, 4),
(129, 11, 5, 2, 1),
(130, 11, 2, 2, 2),
(131, 11, 5, 2, 3),
(132, 11, 5, 2, 4),
(133, 15, 5, 3, 1),
(134, 15, 5, 3, 2),
(135, 15, 5, 3, 3),
(136, 15, 5, 3, 4),
(137, 22, 10, 3, 1),
(138, 22, 5, 3, 2),
(139, 22, 5, 3, 3),
(140, 22, 5, 3, 4),
(141, 4, 5, 1, 1),
(142, 4, 5, 1, 2),
(143, 4, 5, 1, 3),
(144, 4, 5, 1, 4),
(145, 20, 5, 1, 1),
(146, 20, 5, 1, 2),
(147, 20, 8, 1, 3),
(148, 20, 9, 1, 4),
(149, 3, 10, 3, 1),
(150, 3, 4, 3, 2),
(151, 3, 1, 3, 3),
(152, 3, 8, 3, 4);

-- --------------------------------------------------------

--
-- Struktur för tabell `song`
--

CREATE TABLE IF NOT EXISTS `song` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `release_date` date NOT NULL,
  `length` int(10) NOT NULL,
  `artist_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Data i tabell `song`
--

INSERT INTO `song` (`id`, `name`, `release_date`, `length`, `artist_id`) VALUES
(1, 'Do You Love Me?', '1975-02-23', 300, 1),
(2, 'Nobody''s Baby Now', '1975-02-23', 245, 2),
(3, 'Loverman', '1975-06-23', 239, 2),
(4, 'Jangling Jack', '2003-07-23', 242, 3),
(5, 'Red Right Hand', '2005-03-23', 261, 2),
(6, 'I Let Love In', '1999-08-23', 225, 2),
(7, 'Thirsty Dog', '2009-04-23', 281, 6),
(8, 'Ain''t Gonna Rain Anymore', '2012-08-23', 277, 5),
(9, 'Lay Me Low', '1998-01-23', 215, 5),
(10, 'Do You Love Me? (Part Two)', '2001-01-23', 223, 4),
(11, 'Elegia', '2001-06-23', 293, 4),
(12, 'In A Lonely Place', '2004-07-23', 226, 4),
(13, 'Procession', '2001-02-23', 247, 4),
(14, 'Your Silent Face', '2008-05-23', 299, 4),
(15, 'Sunrise', '1989-06-23', 301, 5),
(16, 'Let''s Go', '1977-03-23', 223, 4),
(17, 'Broken Promise', '1971-07-13', 256, 2),
(18, 'Dreams Never End', '0000-00-00', 121, 2),
(19, 'Cries And Whispers', '1995-02-13', 124, 2),
(20, 'All Day Long', '1987-09-23', 198, 1),
(21, 'Sooner Than You Think', '1987-02-23', 147, 3),
(22, 'Leave Me Alone', '2005-03-18', 221, 3);

-- --------------------------------------------------------

--
-- Struktur för tabell `song_album`
--

CREATE TABLE IF NOT EXISTS `song_album` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(10) NOT NULL,
  `song_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `album_id` (`album_id`,`song_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Data i tabell `song_album`
--

INSERT INTO `song_album` (`id`, `album_id`, `song_id`) VALUES
(1, 1, 1),
(2, 3, 1),
(3, 2, 2),
(4, 4, 2),
(5, 1, 3),
(6, 4, 4),
(7, 5, 5),
(8, 5, 6),
(9, 4, 6),
(10, 5, 7),
(11, 2, 8),
(12, 4, 9),
(13, 5, 9),
(14, 2, 10),
(15, 1, 11),
(16, 5, 11),
(17, 2, 12),
(18, 3, 13),
(19, 4, 13),
(20, 1, 14),
(21, 1, 15),
(22, 3, 15),
(23, 4, 15),
(24, 2, 16),
(25, 2, 17),
(26, 3, 18),
(27, 3, 19),
(28, 5, 19),
(29, 1, 20),
(30, 2, 21),
(31, 1, 22),
(32, 2, 22),
(33, 4, 23),
(34, 4, 24),
(35, 5, 24);

-- --------------------------------------------------------

--
-- Struktur för tabell `song_artist`
--

CREATE TABLE IF NOT EXISTS `song_artist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `song_id` int(10) NOT NULL,
  `artist_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `song_id` (`song_id`,`artist_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Data i tabell `song_artist`
--

INSERT INTO `song_artist` (`id`, `song_id`, `artist_id`) VALUES
(1, 1, 1),
(2, 1, 3),
(3, 2, 2),
(4, 2, 4),
(5, 3, 1),
(6, 4, 4),
(7, 5, 5),
(8, 6, 5),
(9, 6, 4),
(10, 7, 5),
(11, 8, 2),
(12, 9, 4),
(13, 9, 5),
(14, 10, 2),
(15, 11, 1),
(16, 11, 5),
(17, 12, 2),
(18, 13, 3),
(19, 13, 4),
(20, 14, 1),
(21, 15, 1),
(22, 15, 3),
(23, 15, 4),
(24, 16, 2),
(25, 17, 2),
(26, 18, 3),
(27, 19, 3),
(28, 19, 5),
(29, 20, 1),
(30, 21, 2),
(31, 22, 1),
(32, 22, 2),
(33, 23, 4),
(34, 24, 4),
(35, 24, 5);

-- --------------------------------------------------------

--
-- Struktur för tabell `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(128) NOT NULL,
  `user_email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Data i tabell `user`
--

INSERT INTO `user` (`id`, `user_name`, `user_email`, `password`, `create_date`) VALUES
(1, 'Thor', 'tor@tor.com', 'thor', '2012-05-21 14:31:36'),
(2, 'Katarina', 'kat@arina.com', 'katarina', '2012-05-21 14:31:36'),
(3, 'Palle', 'p@p.com', 'palle', '2012-05-21 14:31:36'),
(4, 'Fredrik', 'f@f.com', 'fredrik', '2012-05-21 14:31:36'),
(5, 'johan', 'j@j.se', 'johan', '0000-00-00 00:00:00'),
(6, 'fredrik', 'fred@rik.se', 'fredrik', '0000-00-00 00:00:00'),
(8, 'harry', 'ha@ry.se', 'harry', '0000-00-00 00:00:00'),
(11, 'Git', 'git@git.se', 'git', '2012-05-28 15:16:39'),
(19, '', '', '', '2012-05-31 13:22:59'),
(18, 'Lasse', 'lasse@lasse.se', 'lasse', '2012-05-29 23:34:30');
